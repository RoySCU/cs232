import syntaxtree.*;
import visitor.*;
import java.util.*;

class CallGraph {
    public static void main(String[] args){
            MyVisitor myVisitor = new MyVisitor();
            MiniJavaParser myparser = new MiniJavaParser(System.in);
            try {
                    Goal goal = myparser.Goal();
                    goal.accept(myVisitor,null);
            } catch (ParseException e) {
                    System.out.println(e);
            }
    }
}

class MyVisitor extends GJDepthFirst<Object,String>{
    String ClassName;
    public Object visit(MethodDeclaration n, String s) {
            n.f8.accept(this, s+"_"+n.f2.f0.toString());
            n.f10.accept(this,s+"_"+n.f2.f0.toString());
            return null;
    }
    public Object visit(ClassDeclaration n, String s) {
            n.f4.accept(this, n.f1.f0.toString());
            return null;
    }
    public Object visit(ClassExtendsDeclaration n, String s) {
            n.f4.accept(this, n.f1.f0.toString());
            return null;
    }
    public Object visit(MainClass n, String s) {
            n.f15.accept(this, n.f1.f0.toString()+"_"+"main");
            return null;
    }
    //MessageSend
    public Object visit(MessageSend n, String s){
            n.f0.accept(this,s);
            System.out.println(s + " -> "+this.ClassName+"_"+ n.f2.f0.toString());
            n.f4.accept(this, s);
            return null;
    }
    //PrintStatement
    public Object visit(PrintStatement n, String s) {
            n.f2.accept(this, s);
            return null;
    }
    //BlockStatement
    public Object visit(Block n, String s) {
            n.f1.accept(this, s);
            return null;
    }
    //AssignmentStatement
    public Object visit(AssignmentStatement n, String s) {
            n.f2.accept(this, s);
            return null;
    }
    //ArraryAssignmentStatement
    public Object visit(ArrayAssignmentStatement n, String s) {
            n.f2.accept(this, s);
            n.f5.accept(this, s);
            return null;
    }
    //IfStatement
    public Object visit(IfStatement n, String s) {
            n.f2.accept(this, s);
            n.f4.accept(this, s);
            n.f6.accept(this, s);
            return null;
    }
    //WhileStatement
    public Object visit(WhileStatement n, String s) {
            n.f2.accept(this, s);
            n.f4.accept(this, s);
            return null;
    }
    //AndExpression
    public Object visit(AndExpression n, String s){
            n.f0.accept(this, s);
            n.f2.accept(this, s);
            return null;
    }
    //CompareExpression
    public Object visit(CompareExpression n, String s){
            n.f0.accept(this, s);
            n.f2.accept(this, s);
            return null;
    }

    //PlusExpression
    public Object visit(PlusExpression n, String s){
            n.f0.accept(this, s);
            n.f2.accept(this, s);
            return null;
    }
    //MinusExpression
    public Object visit(MinusExpression n, String s){
            n.f0.accept(this, s);
            n.f2.accept(this, s);
            return null;
    }
    //TimesExpression
    public Object visit(TimesExpression n, String s){
            n.f0.accept(this, s);
            n.f2.accept(this, s);
            return null;
    }
    //ArrayLookupExpression
    public Object visit(ArrayLookup n, String s){
            n.f0.accept(this, s);
            n.f2.accept(this, s);
            return null;
    }
    //ArrayLenghExpression
    public Object visit(ArrayLength n, String s){
            n.f0.accept(this, s);
            return null;
    }
    //ExpressionList
    public Object visit(ExpressionList n, String s){
            n.f0.accept(this,s);
            n.f1.accept(this,s);
            return null;
    }
    //ExpressionRest
    public Object visit(ExpressionRest n, String s){
            n.f1.accept(this, s);
            return null;
    }
    //AllocationExpression
    public Object visit(AllocationExpression n, String s){
            this.ClassName=n.f1.f0.toString();
            return null;
    }

}
